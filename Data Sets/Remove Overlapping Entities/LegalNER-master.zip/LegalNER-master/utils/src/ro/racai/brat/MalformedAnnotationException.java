package ro.racai.brat;

public class MalformedAnnotationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4905688237977530896L;

	public MalformedAnnotationException(String string) {
		super(string);
	}

}
