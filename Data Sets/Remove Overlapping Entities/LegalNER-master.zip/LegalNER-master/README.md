# LegalNER
NER in the Legal domain

### Utils

```
java -cp utils.jar KeepLargestAnn <ann_folder>
```

Will process all the files in <ann_folder> and remove smaller entities embedded into larger ones. Make sure to have a backup of your original files as they will get overwritten.

